//Numpy array shape [1]
//Min 1.970142245293
//Max 1.970142245293
//Number of zeros 0

#ifndef B7_H_
#define B7_H_

#ifndef __SYNTHESIS__
model_default_t b7[1];
#else
model_default_t b7[1] = {1.9701422453};
#endif

#endif
